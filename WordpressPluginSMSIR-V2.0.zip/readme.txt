== wordpress SMSIR ==
Version: 2.0
author: Ipe Developers (pejman kheyri)
Contributors: sms.ir
author EMAIL: pejmankheyri@gmail.com
author URI: http://www.sms.ir/
plugin URI: http://sms.ir
Tags: wordpress, sms, sms notifications, sms.ir, ipe.ir

== Description ==
ارسال پیامک به مشتریان در وردپرس

= تغییرات در نسخه 2.0 =

* تغییر کلی ماژول برای پشتیبانی از وب سرویس رست فول پنل

== Installation ==
1. Upload `WordpressPluginSMSIR-V2.0` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu
3. Complete wordpress SMSir Settings
