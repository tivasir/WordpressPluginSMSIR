<p>
	<?php _e('Name', 'wp-sms'); ?>:<br />
	<input id="wp_sms_widget_name" name="wp_sms_widget_name" type="text" value="<?php echo get_option('wp_sms_widget_name'); ?>" />
</p>

<input type="hidden" id="wp_sms_submit_widget" name="wp_sms_submit_widget" value="1" />