<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery("#send_friend").click(function(){
			jQuery("#tell_friend_form").slideToggle();
		});
	})
</script>