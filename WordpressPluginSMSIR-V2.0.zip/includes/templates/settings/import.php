<div class="wrap">
	<h2><?php _e('Import', 'wp-sms'); ?></h2>
	<form method="post" action="" enctype="multipart/form-data">
		<div id="html-upload-ui">
			<p id="async-upload-wrap">
				<input id="async-upload" type="file" name="wps-import-file"/>
				<p class="upload-html-bypass"><?php echo sprintf(__('<code>.xls</code> is the only acceptable format. Please see <a href="%s">this image</a> to show a standard xls import file.', 'wp-sms'), WP_SMS_DIR_PLUGIN.'assets/images/standard-xml-file.png'); ?></p>
			</p>
			
			<p id="async-upload-wrap">
				<label for="wpsms_group_name"><?php _e('Group', 'wp-sms'); ?>:</label>
				<select name="wpsms_group_name" id="wpsms_group_name">
					<?php foreach($get_group_result as $items): ?>
					<option value="<?php echo $items->ID; ?>"><?php echo $items->name; ?></option>
					<?php endforeach; ?>
				</select>
			</p>
			
			<input type="submit" class="button" name="wps_import" value="<?php _e('Upload', 'wp-sms'); ?>" /></td>
		</div>
		
		<h4><a href="<?php echo admin_url(); ?>admin.php?page=wp-sms/subscribe"><?php _e('Back', 'wp-sms'); ?></a></h4>
	</form>
</div>