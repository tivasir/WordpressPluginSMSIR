<div class="wrap">
	<h2><?php _e('About Plugin', 'wp-sms'); ?></h2>
	<p><?php echo sprintf(__('Version plugin: %s', 'wp-sms'), WP_SMS_VERSION); ?></p>
	<p><?php echo sprintf(__('The first free WordPress Iranian plugin that works on Web service messages.', 'wp-sms'), 'http://www.webstudio.ir'); ?></p>
	<p><?php echo sprintf(__('This plugin created by %s from %s gorup', 'wp-sms'), '<a href="http://ipe.ir">Ipe Developers</a>', '<a href="http://ipe.ir">IPE</a>'); ?>
</div>